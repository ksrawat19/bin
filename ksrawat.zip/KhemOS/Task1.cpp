// Task 2: Implementation of CPU scheduling algorithms to find turnaround time and waiting time. a) FCFS b) SJF c) Round Robin (pre-emptive) d) Priority.

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct Process {
    int process_id;
    int burst_time;
    int waiting_time;
    int turnaround_time;
    int priority;
    int remaining_burst_time;
};

// Function to calculate waiting and turnaround times
void calculateTimes(vector<Process>& processes) {
    for (int i=0; i<processes.size(); i++) {
        processes[i].turnaround_time = processes[i].burst_time + processes[i].waiting_time;
    }
}

void printProcesses(const vector<Process>& processes, const string& scheduling_type) {
    double total_waiting_time = 0;
    double total_turnaround_time = 0;

    cout << scheduling_type << " Scheduling:\n";
    cout << "Processes Burst time Waiting time Turn around time\n";
    for (const auto& proc : processes) {
        cout << " " << proc.process_id << "\t\t" << proc.burst_time << "\t\t" 
             << proc.waiting_time << "\t\t" << proc.turnaround_time << endl;
        total_waiting_time += proc.waiting_time;
        total_turnaround_time += proc.turnaround_time;
    }

    double average_waiting_time = total_waiting_time / processes.size();
    double average_turnaround_time = total_turnaround_time / processes.size();

    cout << "Average Waiting Time: " << average_waiting_time << endl;
    cout << "Average Turnaround Time: " << average_turnaround_time << "\n\n";
}

// First-Come, First-Served (FCFS)
void FCFS(vector<Process>& p) {
    p[0].waiting_time = 0;

    for (int i=1; i<p.size(); i++) {
        p[i].waiting_time = p[i - 1].burst_time + p[i - 1].waiting_time;
    }
    calculateTimes(p);
    printProcesses(p, "FCFS");
}

// Shortest Job First (SJF)
bool sjf_comparison(const Process& a, const Process& b) {
    return (a.burst_time < b.burst_time);
}

void SJF(vector<Process>& processes) {
    sort(processes.begin(), processes.end(), sjf_comparison);
    processes[0].waiting_time = 0;

    for (int i=1; i<processes.size(); i++) {
        processes[i].waiting_time = processes[i - 1].burst_time + processes[i - 1].waiting_time;
    }

    calculateTimes(processes);
    printProcesses(processes, "SJF");
}

// Round Robin (Pre-emptive)
void RoundRobin(vector<Process>& processes, int time_quantum) {
    int time = 0;

    for (auto& proc : processes) {
        proc.remaining_burst_time = proc.burst_time;
    }

    while (true) {
        bool done = true;

        for (auto& proc : processes) {
            if (proc.remaining_burst_time > 0) {
                done = false;

                if (proc.remaining_burst_time > time_quantum) {
                    time += time_quantum;
                    proc.remaining_burst_time -= time_quantum;
                } else {
                    time += proc.remaining_burst_time;
                    proc.waiting_time = time - proc.burst_time;
                    proc.remaining_burst_time = 0;
                }
            }
        }
        if (done) break;
    }
    calculateTimes(processes);
    printProcesses(processes, "Round Robin");
}

// Priority Scheduling
bool priority_comparison(const Process& a, const Process& b) {
    return (a.priority > b.priority);
}

void PriorityScheduling(vector<Process>& processes) {
    sort(processes.begin(), processes.end(), priority_comparison);
    processes[0].waiting_time = 0;

    for (int i=1; i<processes.size(); i++) {
        processes[i].waiting_time = processes[i - 1].burst_time + processes[i - 1].waiting_time;
    }

    calculateTimes(processes);
    printProcesses(processes, "Priority");
}

int main() {
    vector<Process> processes_fcfs = {{0, 5}, {1, 3}, {2, 8}, {3, 6}};
    FCFS(processes_fcfs);

    vector<Process> processes_sjf = {{1, 6}, {2, 8}, {3, 7}, {4, 3}};
    SJF(processes_sjf);

    vector<Process> processes_rr = {{1, 10}, {2, 5}, {3, 8}};
    int time_quantum = 2;
    RoundRobin(processes_rr, time_quantum);

    vector<Process> processes_priority = {{1, 10, 3}, {2, 1, 1}, {3, 2, 4}, {4, 1, 5}, {5, 5, 2}};
    PriorityScheduling(processes_priority);

    return 0;
}