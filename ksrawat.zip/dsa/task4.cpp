// Write a program to find the location of a given element using Binary Search. 
#include <iostream>
using namespace std;

int findUbinaryS(int *arr, int _size, int _key){
    int s = 0;
    int e = _size-1;
    int mid;
    while(s<=e){
        mid = (s+e)/2;
        if(arr[mid] == _key){
            return mid+1;
        }
        else if(arr[mid]>_key){
            e = mid-1;
        }
        else{
            s = mid+1;
        }
    }
    return -1;
}

int main(){
    int arr[] = {12,34,56,78,85,98,102};
    int size = sizeof(arr)/sizeof(arr[0]);

    for(int i=0;i<size;i++){
        cout<<arr[i]<<" ";
    }
    cout<<endl;
    int key;
    cout<<"of which element location you wanna find ? : ";
    cin>>key;

    int ans = findUbinaryS(arr, size, key);
    if(ans!=-1){
        cout<<"location of "<<key<<" is "<<ans<<endl;
    }
    else{
        cout<<"element can't find\n";
    }

    return 0;
}