//Program to sort an array of integers in ascending order using insertion sort. 
#include <iostream>
using namespace std;

void insertionSort(int* arr, int _size){
    int key;
    for(int i=1; i<_size; i++){
        key = arr[i];
        int j=i-1;
        while(j>=0 && arr[j]>key){
            arr[j+1] = arr[j];
            j--;
        }
        arr[j+1] = key;
    }
}

int main(){
    int arr[] = {32,51,12,76,5,8,13};
    int size = sizeof(arr)/sizeof(arr[0]);
    cout << "before sort: ";
    for(auto i:arr){
        cout<<i<<" ";
    }
    cout<<endl;
    insertionSort(arr, size);
        cout << "after sort: ";
    for(auto i:arr){
        cout<<i<<" ";
    }
    cout<<endl;
    return 0;
}