//Program to sort an array of integers in ascending order using quick sort.
#include <iostream>
using namespace std;

void quickSort(int* arr, int beg, int end){
    if(beg<end){
        --end;
        int pivot = arr[end];
        int less = beg;
        for(int i=beg; i<end; i++){
            if(arr[i]<=pivot){
                swap(arr[less], arr[i]);
                less++;
            }
        }
        swap(arr[less], arr[end]);

        quickSort(arr, beg, less);
        quickSort(arr, less+1, end+1);
    }
}

int main(){
    int arr[] = {3, 6, 8, 3, 2, 7, 3, 6};
    int size = sizeof(arr)/sizeof(arr[0]);
    cout << "before sort: ";
    for(auto i:arr){
        cout<<i<<" ";
    }
    cout<<endl;
    quickSort(arr, 0, size);
    cout << "after sort: ";
    for(auto i:arr){
        cout<<i<<" ";
    }
    cout<<endl;
    return 0;
}