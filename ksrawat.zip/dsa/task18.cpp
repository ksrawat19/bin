//Task 18: Program to traverse a Binary search tree in Pre-order, In-order and Post-order.
#include <iostream>
using namespace std;

struct Node{
    int data;
    Node* left;
    Node* right;

    Node(int data){
        this->data = data;
        this->left = nullptr;
        this->right = nullptr;
    }
};

struct BST{
    Node* root;
    BST(){
        root = nullptr;
    }

    void insertBST(Node* &root, int data){
        if(root==nullptr){
            root = new Node(data);
            return;
        }
        if(root->data > data){
            insertBST(root->left, data);
        }else{
            insertBST(root->right, data);
        }
    }

    void Traverse_PreOrder(Node* root){
        if(root==nullptr){
            return;
        }
        cout<<root->data<<" ";
        Traverse_PreOrder(root->left);
        Traverse_PreOrder(root->right);
    }
    void Traverse_InOrder(Node* root){
            if(root==nullptr){
            return;
        }
        Traverse_InOrder(root->left);
        cout<<root->data<<" ";
        Traverse_InOrder(root->right);  
    }
    void Traverse_PostOrder(Node* root){
        if(root==nullptr){
            return;
        }
        Traverse_PostOrder(root->left);
        Traverse_PostOrder(root->right);
        cout<<root->data<<" ";
    }

};

int main(){
    BST tree;
    int arr[] = {45, 15, 79, 90, 10, 55, 12, 20, 50};
    int size = sizeof(arr)/sizeof(arr[0]);

    for(auto i:arr){
        tree.insertBST(tree.root, i);
    }

    cout << "Pre-order traversal: ";
    tree.Traverse_PreOrder(tree.root); 

    cout << endl; cout << "In-order traversal: "; 
    tree.Traverse_InOrder(tree.root); 

    cout << endl; cout << "Post-order traversal: "; 
    tree.Traverse_PostOrder(tree.root); 

    cout << endl;
    return 0;
}