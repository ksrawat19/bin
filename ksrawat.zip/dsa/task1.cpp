// Write a program to insert a new element at end as well as at a given position in an array.
#include <iostream> 
using namespace std; 

void insert(int _size, int arr[], int x, int pos){ 

	_size++; 
	for (int i = _size; i >= pos; i--){
		arr[i] = arr[i - 1]; 
		// cout<<i<<" "<<_size<<endl;
    }
	arr[pos - 1] = x; 

    for(int i=0;i<=_size;i++){
        if(i==_size){
            arr[i] = x;
        }
    }
	return; 
} 

int main() 
{ 
	int arr[100] = { 0 }; 
	int i, x, pos = 0;
    int size = 10; 

	for (i = 0; i < 10; i++){
		arr[i] = i + 1; 
    }
	cout<<"Before inserting element\n";
	for (i = 0; i < size; i++){
		cout << arr[i] << " "; 
    }
	cout << endl; 

    cout<<"which element do u wanna insert : ";
    cin>>x;
    cout<<"in which position? : ";
    cin>>pos;

	insert(size, arr, x, pos); 
	cout<<"After inserting element \n";
	for (i = 0; i < size + 2; i++) {
		cout << arr[i] << " "; 
    }
	cout << endl; 

	return 0; 
}