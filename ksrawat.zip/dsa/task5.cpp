// Write a program to implement push and pop operations on a stack using linear array.
#include <iostream>
using namespace std;

class Stack{
    int *arr;
    int stackTop;
    int stackSize;

    public:
    Stack(int size){
        this->arr = new int[size];
        this->stackTop = -1;
        this->stackSize = size;
    }

    // Behaviours
    void push(int x){
        if(stackTop==stackSize-1){
            cout<<"stack overflow\n";
        }
        else{
            stackTop++;
            arr[stackTop] = x;
        }
    }
    void pop(){
        if(stackTop==-1){
            cout<<"stack underflow\n";
        }
        else{
            stackTop--;
        }
    }
    
    void print(){
        for(int i=0;i<=stackTop;i++){
            cout<<arr[i]<<" ";
        }
    }
};

int main(){
    Stack stk(6);

    // to Insert element in stkack
    stk.push(10);    
    stk.push(20);
    stk.push(30);

    stk.pop();
    // stk.pop();
    stk.print();

    return 0;
}