//Program to sort an array of integers in ascending order using bubble sort. 
#include <iostream>
using namespace std;

void bubbleSort(int* arr, int _size){
    for(int i=1; i<_size; i++){
        for(int j=0; j<_size-i; j++){
            if(arr[j] > arr[j+1]){
                swap(arr[j], arr[j+1]);
            }
        }
    }
}

int main(){
    int arr[] = {32,5,12,76,5,8,13};
    int size = sizeof(arr)/sizeof(arr[0]);
    cout << "before sort: ";
    for(auto i:arr){
        cout<<i<<" ";
    }
    cout<<endl;
    bubbleSort(arr, size);
    cout << "after sort: ";
    for(auto i:arr){
        cout<<i<<" ";
    }
    cout<<endl;
    return 0;
}