// Task 8:  Write a recursive function for Tower of Hanoi problem. 
#include <iostream>
using namespace std;

void towerOfHanoi(int n, char source, char destination, char helper) {
    if (n == 1) {
        cout << "Move disk 1 from " << source << " to " << destination << endl;
        return;
    }
    towerOfHanoi(n - 1, source, helper, destination);
    cout << "Move disk " << n << " from " << source << " to " << destination << endl;
    towerOfHanoi(n - 1, helper, destination, source);
}

int main() {
    int n = 3; // Number of disks
    cout<<"Number of disks is "<<n<<endl;
    towerOfHanoi(n, 'A', 'C', 'B'); // A, B and C are names of rods
    return 0;
}
