// Task 10:Write   a   menu   driven   program   to   perform   following   insertion operations in a single linked list: 
// i.  Insertion at beginning 
// ii. Insertion at end 
// iii.Insertion after a given node 
// iv. Traversing a linked list 
#include <iostream>
using namespace std;

struct Node{
    int data;
    Node* next;

    Node(int data){
        this->data = data;
        this->next = nullptr;
    }
};

class LinkedList{
    Node* head = nullptr;
    Node* tail = nullptr;

    public:
    void insertAtBeg(int data){
        Node* newNode = new Node(data);
        if(head == nullptr){
            head = newNode;
            tail = newNode;
            return;
        }
        newNode->next = head;
        head = newNode;
        return;
    }

    void insertAtEnd(int data){
        Node* newNode = new Node(data);
        if(head == nullptr){
            head = newNode;
            tail = newNode;
            return;
        }
        tail->next = newNode;
        tail = newNode;
        return;
    }

    void insertAfterNode(int data, int pos = 1){
        if(pos < 1){
            insertAtBeg(data);
            return;
        }
        if(pos == lenLL()){
            insertAtEnd(data);
            return;
        }
        Node* pre = head;
        int count = 1;
        while(count<pos){
            pre = pre->next;
            count++;
        }
        Node* curr = pre->next;
        Node* newNode = new Node(data);
        pre->next = newNode;
        newNode->next = curr;
        return;
    }

    void traverse(){
        Node* temp = head;
        while(temp!=nullptr){
            cout<<temp->data<<" ";
            temp = temp->next;
        }
        cout<<endl;
    }

    int lenLL(){
        Node* temp = head;
        int count = 0;
        while(temp!=nullptr){
            temp = temp->next;
            count++;
        }
        return count;
    }
};

int main(){
    LinkedList l;

    int choice, value, position;
    do{
        cout<<"1. Insertion at beginning\n";
        cout<<"2. Insertion at the end\n";
        cout<<"3. Insertion after a given node\n";
        cout<<"4. Traversing a linked list\n";
        cout<<"5. Exit\n";

        cout<<"chosse option : ";
        cin>>choice;
        
        switch(choice){
            case 1:
                cout << "Enter value to insert at beginning: ";
                cin >> value;
                l.insertAtBeg(value);
                break;
            case 2:
                cout << "Enter value to insert at end: ";
                cin >> value;
                l.insertAtEnd(value);
                break;
            case 3:
                cout << "Enter value to insert: ";
                cin >> value;
                cout << "Enter position to insert after Node: ";
                cin >> position;
                l.insertAfterNode(value, position);
                break;
            case 4:
                cout << "Linked List: ";
                l.traverse();
                break;
            case 5:
                cout << "Exiting the program." << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    } while (choice != 5);

    return 0;
}