// Write a menu driven program to perform following deletion operations in a single linked list: 
// i.  Deletion at beginning
// ii. Deletion at end
// iii.Deletion after a given node
#include <iostream>
using namespace std;

struct Node{
    int data;
    Node* next;

    Node(int data) : data(data), next(nullptr) {}
};

class LinkedList{
    Node* head;
    Node* sec;
    Node* third;
    Node* fourth;
    Node* fifth;
    Node* tail;

    public:
    LinkedList(){
        head = new Node(10);
        sec = new Node(20);
        third = new Node(30);
        fourth = new Node(40);
        fifth = new Node(50);
        tail = new Node(60);

        head->next = sec;
        sec->next = third;
        third->next = fourth;
        fourth->next = fifth;
        fifth->next = tail;
    }

    int lenLL(){
        int len = 0;
        Node* temp = head;
        while(temp!=nullptr){
            temp = temp->next;
            len++;
        }
        return len;
    }

    void deleteAtBeg(){
        if(head==nullptr){
            cout<<"kya kr rha h byi tu\n";
            return;
        }
        Node* temp = head;
        head = head->next;
        temp->next = nullptr;
        delete temp;
    }

    void deleteAtEnd(){
        if(head==nullptr){
            cout<<"kya kr rha h byi tu\n";
            return;
        }
        if(head->next==nullptr){
            delete head;
            head = nullptr;
            return;
        }
        Node* temp = head;
        while(temp->next->next!=nullptr){
            temp = temp->next;
        }
        delete temp->next;
        temp->next = nullptr;
        tail = temp;
    }

    void deleteAfterNode(int after){
        int len = lenLL();
        if(head==nullptr || after<0 || after>=len){
            cout<<"kya kr rha h byi tu\n";
            return;
        }
        if(after==0){
            deleteAtBeg();
            return;
        }
        if(after==len-1){
            deleteAtEnd();
            return;
        }
        Node* pre = head;
        for(int i=1; i<after; i++){
            pre = pre->next;
        }
        Node* post = pre->next;
        pre->next = post->next;
        post->next = nullptr;
        delete post;
    }

    void printLL(){
        Node* temp = head;
        while(temp!=nullptr){
            cout<<temp->data<<" ";
            temp = temp->next;
        }
        cout<<endl;
    }
};

int main(){
    LinkedList l;
    l.printLL();
    int input = 5, pos = 0;
    do{ 
        cout<<"what operation to perform\n";
        cout<<"1 Deletion at beginning\n";
        cout<<"2 Deletion at end\n";
        cout<<"3 Deletion after a given node\n";
        cout<<"4 Print Node\n";
        cout<<"5 for EXIT\n";
        cout<<"-> chosse option : ";
        cin>>input;
        switch(input){
            case 1: l.deleteAtBeg();
                break;
            case 2: l.deleteAtEnd();
                break;
            case 3:
                cout<<"which position : ";
                cin>>pos;
                l.deleteAfterNode(pos);
                break;
            case 4: l.printLL();
                break;
            case 5: cout<<"EXITED\n";
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    }while(input!=5);

    return 0;
}