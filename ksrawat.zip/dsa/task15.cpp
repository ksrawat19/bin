//Program to sort an array of integers in ascending order using selection sort. 
#include <iostream>
using namespace std;

void selectionSort(int* arr, int _size){
    int min;
    for(int i=0; i<_size-1; i++){
        min = i;
        for(int j=i+1; j<_size; j++){
            if(arr[j] < arr[min]){
                min = j;
            }
        }
        swap(arr[i], arr[min]);
    }
}

int main(){
    int arr[] = {32,5,12,76,5,8,13};
    int size = sizeof(arr)/sizeof(arr[0]);
    cout << "before sort: ";
    for(auto i:arr){
        cout<<i<<" ";
    }
    cout<<endl;
    selectionSort(arr, size);
    cout << "after sort: ";
    for(auto i:arr){
        cout<<i<<" ";
    }
    cout<<endl;
    return 0;
}