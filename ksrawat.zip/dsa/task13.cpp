// Write a program to implement push and pop operations on a queue using linked list. 
#include <iostream>
using namespace std; 

class Node{
    public:
    int data;
    Node* next;

    Node(int data): data(data), next(nullptr) {}
};

class LinkedList{
    private:
    Node* head;
    Node* tail;
    public:
    LinkedList() : head(nullptr), tail(nullptr){}

    void insertionAtTail(int data){
        Node* newNode = new Node(data);
        if(head==nullptr){
            head = tail = newNode;
            return;
        }
        tail->next = newNode;
        tail = newNode;
    }
    void deletionAtBeg(){
        if(head==nullptr){
            cout<<"pagal hai kya\n";
            return;
        }
        Node* temp = head;
        head = head->next;
        temp->next = nullptr;
        delete temp;
    }
    void printLL(){
        Node* temp = head;
        while(temp!=nullptr){
            cout<<temp->data<<" ";
            temp = temp->next;
        }
        cout<<endl;
    }
};

struct Queue{
    LinkedList ll;
    void enqueue(int data){
        ll.insertionAtTail(data);
    }

    void dequeue(){
        ll.deletionAtBeg();
    }

    void print(){
        ll.printLL();
    }
};

int main(){
    Queue q;
    q.enqueue(10);
    q.enqueue(20);
    q.enqueue(30);
    q.enqueue(40);
    q.enqueue(50);

    q.dequeue();
    q.print();
    return 0;
}