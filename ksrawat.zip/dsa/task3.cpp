// Write a program to find the location of a given element using Linear Search.
#include <iostream>
using namespace std;

int findUlinearS(int *arr, int _size, int _key){
    for(int i=0; i<_size; i++){
        if(arr[i] == _key){
            return (i+1);
        }
    }
    return -1;
}

int main(){
    int arr[] = {43,65,3,56,7,33};
    int size = sizeof(arr)/sizeof(arr[0]);

    for(int i=0;i<size;i++){
        cout<<arr[i]<<" ";
    }
    cout<<endl;

    int key;
    cout<<"of which element location you wanna find ? : ";
    cin>>key;

    int ans = findUlinearS(arr, size, key);
    if(ans!=-1){
        cout<<"location of "<<key<<" is "<<ans<<endl;
    }
    else{
        cout<<"element can't find\n";
    }

    return 0;
}