// Write a program to delete an element from a given whose value is given or whose position is given. 
#include <iostream>
using namespace std;

void deleteElement(int *arr, int &_size, int _key){

    bool iskeyFind = false;
    for(int i=0;i<_size;i++){
        if(iskeyFind){
            arr[i] = arr[i+1];
        }
        else if(arr[i] == _key){
                iskeyFind = true;
                _size--;
                i--;
        }
    }
}

int main()
{
    int arr[] = { 11, 15, 6, 8, 9, 10 };
    int size = sizeof(arr) / sizeof(arr[0]);

    cout << "Before\n";
    for (int i = 0; i < size; i++){
        cout << arr[i] << " ";
    }
    cout<<endl;

    int key;
    cout<<"which element you want to delete? : ";
    cin>>key;
    deleteElement(arr, size, key);

    cout << "After Removal of " << key <<endl;
    for (int i = 0; i < size; i++){
        cout << arr[i] << " ";
    }

    return 0;
}