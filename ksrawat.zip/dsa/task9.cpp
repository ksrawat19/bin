// Task 9: Write a program to implement insertion and deletion operations in a queue using linear array.
#include <iostream>
using namespace std;

struct Queue{
    int* arr;
    int size;
    int front;
    int rear;

    Queue(int size){
        this->arr = new int[size];
        this->size = size;
        this->front = -1;
        this->rear = -1;
    }

    void insertElement(int data){
        if(rear==size-1){
            cout<<"queue is overflow\n";
            return;
        }
        if(rear == -1){
            front++;
        }
        rear++;
        arr[rear] = data;
        return;
    }

    void deletElement(){
        if(front == rear){
            cout<<"queue is underflow\n";
            return;
        }
        front++;
        if(front==rear){
            front = -1;
            rear = -1;
        }
    }

    int getFront(){
        if(front == rear){
            cout<<"queue is empty\n";
            return -1;            
        }
        else{
            return arr[front];
        }
    }

    int getBack(){
        if(rear == size){
            return -1;
        }
        else{
            return arr[rear];
        }
    }

    int getSize(){
        return rear-front+1;
    }
};

int main(){
    Queue q(5);
    q.insertElement(10);
    q.insertElement(20);
    q.insertElement(30);
    q.insertElement(40);
    q.insertElement(50);

    cout<<"Size : "<<q.getSize()<<endl;
    q.deletElement();
    cout<<"after deleting one element\n";
    cout<<"Size : "<<q.getSize()<<endl;

    cout<<"front element : "<<q.getFront()<<endl;
    cout<<"rear element : "<<q.getBack()<<endl;  

    return 0;
}