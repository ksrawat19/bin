//  Write a program to implement push and pop operations on a stack using linked list. 
#include <iostream>
using namespace std; 

class Node{
    public:
    int data;
    Node* next;

    Node(int data): data(data), next(nullptr) {}
};

class LinkedList{
    private:
    Node* head;
    public:
    LinkedList() : head(nullptr) {}

    void insertionAtBeg(int data){
        if(head==nullptr){
            head = new Node(data);
            return;
        }
        Node* newNode = new Node(data);
        newNode->next = head;
        head = newNode;
    }
    void deletionAtBeg(){
        if(head==nullptr){
            cout<<"pagal hai kya\n";
            return;
        }
        Node* temp = head;
        head = head->next;
        temp->next = nullptr;
        delete temp;
    }
    void printLL(){
        Node* temp = head;
        while(temp!=nullptr){
            cout<<temp->data<<" ";
            temp = temp->next;
        }
        cout<<endl;
    }
};

struct Stack{
    LinkedList ll;
    void push(int data){
        ll.insertionAtBeg(data);
    }

    void pop(){
        ll.deletionAtBeg();
    }

    void print(){
        ll.printLL();
    }
};

int main(){
    Stack s;
    s.push(10);
    s.push(20);
    s.push(30);
    s.push(40);
    s.push(50);

    s.pop();
    s.print();
    return 0;
}