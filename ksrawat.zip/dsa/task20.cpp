// Program to traverse graphs using DFS. 
#include <iostream>
#include <vector>
using namespace std;

class Graph {
    int V;
    vector<vector<int>> adj;

public:
    Graph(int V);
    void addEdge(int v, int w);
    void DFSUtil(int v, vector<bool>& visited);
    void DFS(int s);
};

Graph::Graph(int V) {
    this->V = V;
    adj.resize(V);
}

void Graph::addEdge(int v, int w) {
    adj[v].push_back(w);
}

void Graph::DFSUtil(int v, vector<bool>& visited) {
    visited[v] = true;
    cout << v << " ";

    for (int adjNode : adj[v]) {
        if (!visited[adjNode]) {
            DFSUtil(adjNode, visited);
        }
    }
}

void Graph::DFS(int s) {
    vector<bool> visited(V, false);
    DFSUtil(s, visited);
}

int main() {
    Graph g(6);
    g.addEdge(1, 2);
    g.addEdge(1, 3);
    g.addEdge(2, 1);
    g.addEdge(2, 4);
    g.addEdge(3, 1);
    g.addEdge(3, 5);
    g.addEdge(4, 2);
    g.addEdge(5, 3);

    cout << "DFS starting from vertex 1: ";
    g.DFS(1);

    return 0;
}