// Task 7:  Write a program to evaluate a postfix expression using stacks. 
#include <iostream>
#include <stack>
#include <string>

using namespace std;

// Function to perform the operation
int performOperation(char operation, int operand1, int operand2) {
    switch (operation) {
        case '+': return operand1 + operand2;
        case '-': return operand1 - operand2;
        case '*': return operand1 * operand2;
        case '/': return operand1 / operand2;
        default: return 0;
    }
}

// check if a character is a digit
bool isDigit(char c) {
    return c >= '0' && c <= '9';
}

// Function to evaluate postfix expression
int evaluatePostfix(string postfix) {
    int len = postfix.length();
    stack<int> s;

    for (int i=0; i<len; i++) {
        char c = postfix[i];
        // If the character is an operand, push it to the stack
        if (isDigit(c)) {
            s.push(c - '0');  // Convert char to int
        } 
        else {
            // Operator encountered
            int operand2 = s.top(); s.pop();
            int operand1 = s.top(); s.pop();
            int result = performOperation(c, operand1, operand2);
            s.push(result);
        }
    }

    return s.top();
}

int main() {
    string postfix = "231*+9-";
    cout << "Postfix Expression: " << postfix << endl;
    int result = evaluatePostfix(postfix);
    cout << "Evaluation Result: " << result << endl;
    return 0;
}