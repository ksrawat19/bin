// #include <stdio.h>
// #include <stdbool.h>
// #include <limits.h>

// struct Process {
//     int arrivalTime;
//     int burstTime;
//     int turnAroundTime;
//     int waitingTime;
//     int remaining_burstTime;
//     int priority;
// };

// void print(struct Process* p, int n) {
//     float avgTurnAroundTime = 0;
//     float avgWaitingTime = 0;

//     printf("Process ArivalTime BurstTime TurnAroundTime WaitingTime \n");
//     for (int i = 0; i < n; i++) {
//         printf("%d\t%d\t   %d\t\t %d\t\t%d\n", i, p[i].arrivalTime, p[i].burstTime, p[i].turnAroundTime, p[i].waitingTime);

//         avgTurnAroundTime += p[i].turnAroundTime;
//         avgWaitingTime += p[i].waitingTime;
//     }
//     printf("Average Turn Around Time : %f \n", avgTurnAroundTime / n);
//     printf("Average Wating Time : %f \n", avgWaitingTime / n);
// }

// void FCFS(struct Process* p, int n) {
//     printf("FCFS Method\n");
//     int completionTime = 0;
//     for (int i = 0; i < n; i++) {
//         if (completionTime < p[i].arrivalTime) {
//             completionTime = p[i].arrivalTime;
//         }
//         p[i].waitingTime = completionTime - p[i].arrivalTime;
//         completionTime += p[i].burstTime;
//         p[i].turnAroundTime = p[i].waitingTime + p[i].burstTime;
//     }
//     print(p, n);
// }

// void SJF(struct Process* p, int n) {
//     printf("SJF Method\n");
//     bool done[n];
//     for (int i = 0; i < n; i++) done[i] = false;
    
//     int time = 0, completed = 0;
//     while (completed < n) {
//         int minBurstTime = INT_MAX, shortestProcess = -1;
//         for (int i = 0; i < n; i++) {
//             if (p[i].arrivalTime <= time && !done[i] && p[i].burstTime < minBurstTime) {
//                 minBurstTime = p[i].burstTime;
//                 shortestProcess = i;
//             }
//         }
//         if (shortestProcess != -1) {
//             p[shortestProcess].waitingTime = time - p[shortestProcess].arrivalTime;
//             time += p[shortestProcess].burstTime;
//             p[shortestProcess].turnAroundTime = time - p[shortestProcess].arrivalTime;
//             done[shortestProcess] = true;
//             completed++;
//         } else {
//             time++;
//         }
//     }
//     print(p, n);
// }

// void Priority(struct Process* p, int n) {
//     printf("Priority Method\n");
//     bool done[n];
//     for (int i = 0; i < n; i++) done[i] = false;
    
//     int time = 0, completed = 0;
//     while (completed < n) {
//         int highestPriority = INT_MAX, highestPriorityProcess = -1;
//         for (int i = 0; i < n; i++) {
//             if (p[i].arrivalTime <= time && !done[i] && p[i].priority < highestPriority) {
//                 highestPriority = p[i].priority;
//                 highestPriorityProcess = i;
//             }
//         }
//         if (highestPriorityProcess != -1) {
//             p[highestPriorityProcess].waitingTime = time - p[highestPriorityProcess].arrivalTime;
//             time += p[highestPriorityProcess].burstTime;
//             p[highestPriorityProcess].turnAroundTime = time - p[highestPriorityProcess].arrivalTime;
//             done[highestPriorityProcess] = true;
//             completed++;
//         } else {
//             time++;
//         }
//     }
//     print(p, n);
// }

// void roundRobin(struct Process* p, int n, int quantum) {
//     printf("Round Robin Method\n");
//     int remainingTime[n];
//     for (int i = 0; i < n; i++) {
//         remainingTime[i] = p[i].burstTime;
//     }
//     int t = 0;
//     while (1) {
//         bool done = true;
//         for (int i = 0; i < n; i++) {
//             if (remainingTime[i] > 0) {
//                 done = false;

//                 if (remainingTime[i] > quantum) {
//                     t += quantum;
//                     remainingTime[i] -= quantum;
//                 } else {
//                     t += remainingTime[i];
//                     p[i].waitingTime = t - p[i].burstTime;
//                     remainingTime[i] = 0;
//                 }
//             }
//         }
//         if (done) break;
//     }
//     for (int i = 0; i < n; i++) {
//         p[i].turnAroundTime = p[i].burstTime + p[i].waitingTime;
//     }
//     print(p, n);
// }


// void roundRobin(struct Process* p, int n, int quantum){
//     printf("Round Robin Method\n");
//     int remainingTime[n];
//     for(int i = 0; i < n; i++){
//         remainingTime[i] = p[i].burstTime;
//     }
//     int t = 0;
//     while(1){
//         bool done = true;
//         for(int i = 0; i < n; i++){
//             if(remainingTime[i] > 0){
//                 done = false;

//                 if(remainingTime[i] > quantum){
//                     t += quantum;
//                     remainingTime[i] -= quantum;
//                 }else{
//                     t += remainingTime[i];
//                     p[i].waitingTime = t - p[i].burstTime;
//                     remainingTime[i] = 0;
//                 }
//             }
//         }
//         if(done) break;
//     }
//     for(int i = 0; i < n; i++){
//         p[i].turnAroundTime = p[i].burstTime + p[i].waitingTime;
//     }
//     print(p, n);
// }
// int main() {
//     int n = 4;
//     struct Process p[n];
//     p[0].arrivalTime = 0; p[0].burstTime = 5; p[0].priority = 2;
//     p[1].arrivalTime = 1; p[1].burstTime = 3; p[1].priority = 1;
//     p[2].arrivalTime = 2; p[2].burstTime = 8; p[2].priority = 3;
//     p[3].arrivalTime = 3; p[3].burstTime = 6; p[3].priority = 2;

    // Uncomment one of the following to test different scheduling algorithms
    // FCFS(p, n);
    // SJF(p, n);
    // Priority(p, n);
//     roundRobin(p, n, 2);
//     return 0;
// }
