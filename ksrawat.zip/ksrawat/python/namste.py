print("Namste")
x = 10
print(x)