# M E T H O D 1
def f1(n):
    if(n==0 or n==1):
        print(n)
    else:
        prev = 0
        next = 1
        ans = None
        for i in range(1,n):
            ans = prev+next
            prev = next
            next = ans

        print(ans)

# M E T H O D 2
def f2(n):
    if(n==0 or n==1): return n

    return f2(n-1) + f2(n-2)


n = int(input())

# f1(n)

print(f2(n))