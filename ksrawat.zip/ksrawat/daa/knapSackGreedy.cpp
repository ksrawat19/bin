#include <iostream>
#include <algorithm>
using namespace std;

struct Item{
    int weight;
    int profit;
    int pw;

    Item(): weight(0), profit(0) {}
    Item(int weight, int profit): weight(weight), profit(profit), pw(profit/weight) {}
};

bool compare(Item a, Item b) {
    return a.pw > b.pw;
}

// greedy about both
int knapSackGreedy(Item* obj, int n, int capacity) {
    
}

int main(){
    int n = 3;
    int capacity = 20;
    Item* obj = new Item[n];
    obj[0] = Item(25, 18);
    obj[1] = Item(24, 15);
    obj[2] = Item(15, 10);

    cout<<knapSackGreedy(obj, n, capacity);
    return 0;
}